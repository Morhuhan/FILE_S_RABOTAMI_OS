// 2018 ReVoL Primer Template
// mainf.h
#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <stdio.h>
void mainf();
int main() {
    mainf();
    return 0;
}
