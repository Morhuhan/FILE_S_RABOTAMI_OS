// 2018 ReVoL Primer Template
#pragma once
#include "targetver.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "resource.h"
HINSTANCE hInst;
HWND hWndMain;
