// 2018 ReVoL Primer Template
// writer.cpp
#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "writer.h"

int main(int argc, char* argv[]) {
    if (argc < 4) {
        printf("\nUsage:\nwriter number attempts delay\n\n");
        return 1;
    }
    int number = atoi(argv[1]);
    if (number < 1 || number > 99) {
        printf("\nInvalid number.\n\n");
        return 1;
    }
    int attempts = atoi(argv[2]);
    if (attempts < 1 || attempts > 1000) {
        printf("\nInvalid attempts.\n\n");
        return 1;
    }
    int delay = atoi(argv[3]);
    if (delay < 0 || delay > 1000) {
        printf("\nInvalid delay.\n\n");
        return 1;
    }
    mainf(number, attempts, delay);
    printf("Press any key to finish...");
    _getch();
    _putch(13);
    _putch(10);
    return 0;
}
