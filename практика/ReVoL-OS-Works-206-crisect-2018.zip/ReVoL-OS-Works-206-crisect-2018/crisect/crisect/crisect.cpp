// 2018 ReVoL Primer Template
// crisect.cpp
#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "crisect.h"

int main() {
    mainf();
    return 0;
}
