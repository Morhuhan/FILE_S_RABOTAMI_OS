// 2018 ReVoL Primer Template
// mutex.cpp
#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include "mutex.h"

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("\nProcess number wasn't supplied.\n\n");
        return 1;
    }
    int n = atoi(argv[1]);
    mainf(n);
    return 0;
}

