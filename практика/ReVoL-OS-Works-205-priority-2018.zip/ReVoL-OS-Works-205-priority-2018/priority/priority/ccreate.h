// 2018 ReVoL Primer Template
// ccreate.h
// �����
HFONT CCreateFont(HWND hWnd, const char * Name, int Size) {
    int dpi = GetDeviceCaps(GetDC(hWnd), LOGPIXELSY);
    return CreateFont(-MulDiv(Size, dpi, 72), 0, 0, 0, 0, 0, 0, 0, RUSSIAN_CHARSET, 0, 0, 0, 0, Name);
}
// �������
HWND CCreateLabel(HINSTANCE hInst, HWND Parent, int Left, int Top, int Width, int Height, HFONT hFont, const char * Text) {
    int style = WS_VISIBLE | WS_CHILD;
    HWND hWnd = CreateWindow("STATIC", Text, style, Left, Top, Width, Height, Parent, 0, hInst, 0);
    if (hWnd) SendMessage(hWnd, WM_SETFONT, (WPARAM)hFont, 0);
    return hWnd;
}
// ������
HWND CCreateButton(HINSTANCE hInst, HWND Parent, int Left, int Top, int Width, int Height, int ID, HFONT hFont, const char * Text) {
    int style = WS_VISIBLE | WS_CHILD | BS_NOTIFY;
    HWND hWnd = CreateWindow("BUTTON", Text, style, Left, Top, Width, Height, Parent, (HMENU)ID, hInst, 0);
    if (hWnd) SendMessage(hWnd, WM_SETFONT, (WPARAM)hFont, 0);
    return hWnd;
}
// ������
HWND CCreateListBox(HINSTANCE hInst, HWND Parent, int Left, int Top, int Width, int Height, HFONT hFont) {
    int style = WS_TABSTOP | WS_VISIBLE | WS_CHILD | LBS_NOTIFY | LBS_NOINTEGRALHEIGHT;
    HWND hWnd = CreateWindowEx(WS_EX_CLIENTEDGE, "LISTBOX", 0, style, Left, Top, Width, Height, Parent, (HMENU)0, hInst, 0);
    if (hWnd) SendMessage(hWnd, WM_SETFONT, (WPARAM)hFont, 0);
    return hWnd;
}
// ���� ��� ����� ������ �����
HWND CCreateEdit3D(HINSTANCE hInst, HWND Parent, int Left, int Top, int Width, int Height, int ID, HFONT hFont, const char * Text) {
    int style = WS_TABSTOP | WS_VISIBLE | WS_CHILD | ES_NUMBER | ES_LEFT;
    HWND hWnd = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", Text, style, Left, Top, Width, Height, Parent, (HMENU)ID, hInst, 0);
    if (hWnd) SendMessage(hWnd, WM_SETFONT, (WPARAM)hFont, 0);
    return hWnd;
}
